# Generated from task_2_1.g4 by ANTLR 4.5.3
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .task_2_1Parser import task_2_1Parser
else:
    from task_2_1Parser import task_2_1Parser

# This class defines a complete listener for a parse tree produced by task_2_1Parser.
class task_2_1Listener(ParseTreeListener):

    # Enter a parse tree produced by task_2_1Parser#expr.
    def enterExpr(self, ctx:task_2_1Parser.ExprContext):
        pass

    # Exit a parse tree produced by task_2_1Parser#expr.
    def exitExpr(self, ctx:task_2_1Parser.ExprContext):
        pass


    # Enter a parse tree produced by task_2_1Parser#aaa.
    def enterAaa(self, ctx:task_2_1Parser.AaaContext):
        pass

    # Exit a parse tree produced by task_2_1Parser#aaa.
    def exitAaa(self, ctx:task_2_1Parser.AaaContext):
        pass


    # Enter a parse tree produced by task_2_1Parser#add.
    def enterAdd(self, ctx:task_2_1Parser.AddContext):
        pass

    # Exit a parse tree produced by task_2_1Parser#add.
    def exitAdd(self, ctx:task_2_1Parser.AddContext):
        pass


    # Enter a parse tree produced by task_2_1Parser#inc.
    def enterInc(self, ctx:task_2_1Parser.IncContext):
        pass

    # Exit a parse tree produced by task_2_1Parser#inc.
    def exitInc(self, ctx:task_2_1Parser.IncContext):
        pass


    # Enter a parse tree produced by task_2_1Parser#start.
    def enterStart(self, ctx:task_2_1Parser.StartContext):
        pass

    # Exit a parse tree produced by task_2_1Parser#start.
    def exitStart(self, ctx:task_2_1Parser.StartContext):
        pass


